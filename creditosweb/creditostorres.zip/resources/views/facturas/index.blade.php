@extends('layout.index')
@section('contenido')
<style type="text/css">
    @media (min-width: 768px) {
        #modal-content {
            -webkit-box-shadow: 0 2px 3px rgba(0, 0, 0, 0.125);
            box-shadow: 0 2px 3px rgba(0, 0, 0, 0.125);
            width: 111%;
            top: 5%;
            left: -6%;
        }
    }
</style>
<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
    <div class="row">
        <div class="col-lg-12">
            <h1 class="page-header">Facturas</h1>
        </div>
        <!-- /.col-lg-12 -->
    </div>
    <!-- /.row -->
    <div class="row">
        <table class="table table-striped table-bordered table-hover" id="tableusuario">
            <thead>
            <th>Id Factura</th>
            <th>Vendedor</th>
            <th>Impuestos</th>
            <th>Subtotal</th>
            <th>Total</th>
            <th>Fecha Factura</th>
            <th>Detallado</th>
            </thead>
        </table>
    </div>
</div>

<div class="modal fade" id="modalfacturadetalle" tabindex="-1" role="dialog" aria-labelledby="modalfacturadetalle" aria-hidden="true">
        <form method="post" name="frmfacturadetalle" id="frmfacturadetalle">
            <div class="modal-dialog modal-lg" role="document">
                <div class="modal-content" id="modal-content">
                    <div class="modal-header">
                        <h3 class="modal-title" id="exampleModalLabel">Factura Detallada
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                        </h3>
                    </div>
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            	<div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                                    <label>Número de Factura</label>
                                    <input type="text" class="form-control" id="nrofactura" name="nrofactura">
                                </div>
                                <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                                    <label>Fecha de la Factura</label>
                                    <input type="text" class="form-control" id="fechafactura" name="fechafactura">
                                </div>
                                <div class="col-lg-3 col-md- col-sm-12 col-xs-12">
                                    <label>Cliente</label>
                                    <input type="text" class="form-control" id="cliente" name="cliente">
                                </div>
                                <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                                    <label>Vendedor</label>
                                    <input type="text" class="form-control" id="vendedor" name="vendedor">
                                </div>
                            </div>
                        </div>
                        <br>
                        <div class="row">
                            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            	<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
                                    <label>Impuesto</label>
                                    <input type="text" class="form-control" id="impuesto" name="impuesto">
                                </div>
                                <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
                                    <label>Subtotal</label>
                                    <input type="text" class="form-control" id="subtotal" name="subtotal">
                                </div>
                                <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
                                    <label>Total</label>
                                    <input type="text" class="form-control" id="total" name="total">
                                </div>
                            </div>
                        </div>
                        <br><br>
                        <div class="row">
                            <div class="tabbable col-lg-12 col-md-12 col-sm-10 col-xs-10">
                                <ul class="nav nav-tabs">
                                    <li role="presentation" class="active"><a href="#tab1_ver" data-toggle="tab">Detalle de Factura</a></li>
                                </ul>
                            </div>
                            <div  class="tab-content col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                <div class="tab-pane active" id="tab1_ver">
                                    <br>
                                    <h3>Productos de la Factura</h3>
                                    <table class="table table-striped table-bordered table-hover" id="tabledetalle" style="width: 100%;">
                                        <thead>
                                        <th>Producto</th>
                                        <th>Cantidad</th>
                                        <th>Descuento</th>
                                        <th>Subtotal</th>
                                        <th>Total</th>
                                        </thead>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
                    </div>
                </div>
            </div>
        </form>
    </div>

<script type="text/javascript">
	$(document).ready(function(){
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': "<?= csrf_token(); ?>"
            }
        });
        $('#tableusuario').DataTable(
            {
                destroy: true,
                processing: true,
                serverSide: true,
                ajax:
                    {
                        url: "{{url('/facturas/busqueda')}}",
                        method: 'POST'
                    },
                columns: [
                    {data: 'id', name: 'invoice.id'},
                    {data: 'username', name: 'users.name'},
                    {data: 'taxes', name: 'invoice.taxes'},
                    {data: 'subtotal', name: 'invoice.subtotal'},
                    {data: 'total', name: 'invoice.total'},
                    {data: 'created_at', name: 'invoice.created_at'},
                    {
                        sortable: false,
                        "render": function ( data, type, full, meta ) {
                            var buttonID = full.id;
                            return '<button class="btn btn-info" onclick=\'editar("'+buttonID+'");\' type="button" title="Detallado"><i class="fa fa-search" aria-hidden="true"><a href="#"></a></i></button>';
                        }
                    }
                ],
                "columnDefs": [
                    { "searchable": false, "targets": 6 }
                ],
                "language": {
                    "sProcessing":     "Procesando..",
                    "sLengthMenu":     "Mostrar _MENU_ registros",
                    "sZeroRecords":    "No se encontraron resultados",
                    "sEmptyTable":     "Ningun dato disponible en la tabla",
                    "sInfo":           "Mostrando registros del  _START_ al _END_ de un total de _TOTAL_ registros",
                    "sInfoEmpty":      "Mostrando registros del 0 al 0 de un total de 0 registros",
                    "sInfoFiltered":   "(Filtrando de un total de _MAX_ registros)",
                    "sInfoPostFix":    "",
                    "sSearch":         "Buscar:",
                    "sUrl":            "",
                    "sInfoThousands":  ",",
                    "sLoadingRecords": "Cargando..",
                    "oPaginate": {
                        "sFirst":    "Primero",
                        "sLast":     "Ultimo",
                        "sNext":     "Siguiente",
                        "sPrevious": "Anterior"
                    },
                    "oAria": {
                        "sSortAscending":  ": Activar para ordenar la columna de manera ascendente",
                        "sSortDescending": ": Activar para ordenar la columna de manera descendente"
                    }
                }
            });
    });

    function editar(id)
    {
    	var form = $('#frmfacturadetalle');
        form.attr('action',"{{url('/facturas/detallado')}}");
        var url = form.attr('action');
        var token =  "<?= csrf_token(); ?>";
        var data = getFormData(form);
        $.ajax({
            type: "POST",
            url : url,
            data: {id:id,_token:token},
            success: function(result)
            {
            	$.each(result,function(i,item){
            		$('#nrofactura').val(item.invoice);
            		$('#fechafactura').val(item.created_at);
            		$('#cliente').val(item.nombrecliente);
            		$('#vendedor').val(item.nombrevendedor);
            		$('#impuesto').val(item.taxes);
            		$('#subtotal').val(item.subtotal);
            		$('#total').val(item.total);
            	});
            	$.ajaxSetup({
		            headers: {
		                'X-CSRF-TOKEN': "<?= csrf_token(); ?>"
		            }
		        });
		        $('#tabledetalle').DataTable(
		            {
		                destroy: true,
		                processing: true,
		                serverSide: true,
		                ajax:
		                    {
		                        url: '{{ url('/facturas/detalladotable')}}/'+id,
		                        method: 'POST'
		                    },
		                columns: [
		                    {data: 'nombreproducto', name: 'i.name'},
		                    {data: 'quantity', name: 'items_invoice.name'},
		                    {data: 'disccount', name: 'items_invoice.taxes'},
		                    {data: 'subtotal', name: 'items_invoice.subtotal'},
		                    {data: 'total', name: 'items_invoice.total'}
		                ],
		                "language": {
		                    "sProcessing":     "Procesando..",
		                    "sLengthMenu":     "Mostrar _MENU_ registros",
		                    "sZeroRecords":    "No se encontraron resultados",
		                    "sEmptyTable":     "Ningun dato disponible en la tabla",
		                    "sInfo":           "Mostrando registros del  _START_ al _END_ de un total de _TOTAL_ registros",
		                    "sInfoEmpty":      "Mostrando registros del 0 al 0 de un total de 0 registros",
		                    "sInfoFiltered":   "(Filtrando de un total de _MAX_ registros)",
		                    "sInfoPostFix":    "",
		                    "sSearch":         "Buscar:",
		                    "sUrl":            "",
		                    "sInfoThousands":  ",",
		                    "sLoadingRecords": "Cargando..",
		                    "oPaginate": {
		                        "sFirst":    "Primero",
		                        "sLast":     "Ultimo",
		                        "sNext":     "Siguiente",
		                        "sPrevious": "Anterior"
		                    },
		                    "oAria": {
		                        "sSortAscending":  ": Activar para ordenar la columna de manera ascendente",
		                        "sSortDescending": ": Activar para ordenar la columna de manera descendente"
		                    }
		                }
		            });
                $('#modalfacturadetalle').modal('show');

            }
        });
    	
    }
</script>
@endsection