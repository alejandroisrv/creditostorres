@extends('layout.index')
@section('contenido')

<script src="{{ asset('vendor/chart/Chart.min.js') }}"></script>

<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
	<div class="row">
		<center><h2>Dashboard</h2></center>
	</div>
</div>
<br><br>
<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
	<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
		<div class="panel panel-primary">
		  <div class="panel-body">
		    {!! $chartjs->render() !!}
		  </div>
		  <div class="panel-footer">Gráfica Ventas por Mes</div>
		</div>
	</div>
	<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
		<div class="panel panel-primary">
		  <div class="panel-body">
		    {!! $chartround->render() !!}
		  </div>
		  <div class="panel-footer">Gráfica Movimientos Entrantes vs Movimientos Salientes</div>
		</div>
	</div>
</div>
<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
	<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
		<div class="panel panel-primary">
		  <div class="panel-body">
		    {!! $chartpie->render() !!}
		  </div>
		  <div class="panel-footer">Gráfica Ventas Vs Devoluciones</div>
		</div>
	</div>
	<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
		<div class="panel panel-primary">
		  <div class="panel-body">
		    {!! $chartlist->render() !!}
		  </div>
		  <div class="panel-footer">Gráfica de saldo facturado</div>
		</div>
	</div>
</div>
@endsection