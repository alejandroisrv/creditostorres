
<?php $__env->startSection('contenido'); ?>

<script src="<?php echo e(asset('vendor/chart/Chart.min.js')); ?>"></script>

<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
	<div class="row">
		<center><h2>Dashboard</h2></center>
	</div>
</div>
<br><br>
<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
	<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
		<div class="panel panel-primary">
		  <div class="panel-body">
		    <?php echo $chartjs->render(); ?>

		  </div>
		  <div class="panel-footer">Gráfica Ventas por Mes</div>
		</div>
	</div>
	<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
		<div class="panel panel-primary">
		  <div class="panel-body">
		    <?php echo $chartround->render(); ?>

		  </div>
		  <div class="panel-footer">Gráfica Movimientos Entrantes vs Movimientos Salientes</div>
		</div>
	</div>
</div>
<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
	<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
		<div class="panel panel-primary">
		  <div class="panel-body">
		    <?php echo $chartpie->render(); ?>

		  </div>
		  <div class="panel-footer">Gráfica Ventas Vs Devoluciones</div>
		</div>
	</div>
	<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
		<div class="panel panel-primary">
		  <div class="panel-body">
		    <?php echo $chartlist->render(); ?>

		  </div>
		  <div class="panel-footer">Gráfica de saldo facturado</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>