<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;

use DB;

use DataTables;

use App\Models\invoice;

use App\Models\itemsinvoice;

use App\Models\head;

use App\Models\sales;

use App\Models\salescommision;

use App\Models\paymentagreement;

use App\Models\payments;

use App\Models\delinquentclient;

use App\Models\movements;

class FacturaController extends Controller
{

    public function index()
    {
        return view('facturas.index');
    }

    public function busquedafacturas(request $request)
    {
        $facturas_id = DB::table('invoice')
            ->select(DB::raw("invoice.id, invoice.user, invoice.taxes,invoice.subtotal, invoice.total, invoice.created_at, users.name as username"))
            ->leftjoin('users', 'users.id', '=', 'invoice.user')
            ->orderBy('invoice.id', 'ASC');


        return DataTables::of($facturas_id)->make(true);
    }

    public function detalladofactura(request $request)
    {
        $id = $request->get('id');

        $consulta = DB::table('head')
            ->select(DB::raw("head.invoice, head.client, head.seller, invoice.taxes, invoice.subtotal,invoice.total, invoice.created_at, clients.name as nombrecliente, users.name as nombrevendedor"))
            ->leftjoin('clients', 'clients.id', '=', 'head.client')
            ->leftjoin('users', 'users.id', '=', 'head.seller')
            ->leftjoin('invoice', 'invoice.id', '=', 'head.invoice')
            ->where('head.invoice', $id)
            ->get();

        return $consulta;
    }

    public function detalladotablefactura(request $request, $id)
    {
        $consulta = DB::table('items_invoice as ii')
            ->select(DB::raw("i.id, mov.quantity, ii.disccount, ii.subtotal, ii.total, i.name as nombreproducto"))
            ->join('movements as mov', 'ii.id_movimiento', 'mov.id')
            ->join('items as i', 'mov.id_item', 'i.id')
            ->where('mov.id_invoice', $id);

        /*
                $consulta = DB::table('items_invoice')
                                ->select(DB::raw("items_invoice.item, items_invoice.quantity, items_invoice.disccount, items_invoice.subtotal, items_invoice.total, items.name as nombreproducto"))
                                ->leftjoin('items','items.id','=','items_invoice.item')
                                ->where('items_invoice.invoice',$id);
        */
        return DataTables::of($consulta)->make(true);
    }

    public function crearfactura(request $request)
    {
        $fechaactual = date("y-m-d H:i:s");

        try {

            $add = new invoice;
            $add->user = $request->get('user');
            $add->taxes = $request->get('taxes_total');
            $add->subtotal = $request->get('subtotal_total');
            $add->state = $request->get('state');
            $add->created_at = $fechaactual;
            $add->save();

            $Id_Datos = invoice::select('id')->orderBy('id', 'desc')->first()->get();
            $dato_id = '';
            foreach ($Id_Datos as $dato) {
                $dato_id = $dato->id;
            }
            // recibo la variable array con los elementos de la compra 
            $items = $request->get('items');
            $cantidad = $request->get('quatity');
            $descuento = $request->get('disccount');
            $subtotal = $request->get('subtotal');
            $total = $request->get('total');
            $comments = $request->get('comments');
            $conteo = count($items);

            $calculo = 0;
            $acumulado = 0;

            for ($i = 0; $i < $items; $i++) {
                $additems = new itemsinvoice;
                $additems->item = $items[$i];
                $additems->invoice = $dato_id;
                $additems->quantity = $cantidad[$i];
                $additems->disccount = $descuento[$i];
                $additems->subtotal = $subtotal[$i];
                $additems->total = $total[$i];
                $additems->created_at = $fechaactual;
                $additems->comments = $comments[$i];
                $additems->save();

                $consultaitem = DB::table('items')->select('commision', 'id_local')->where('id', $items[$i])->first();

                $calculo = $total[$i] * $consultaitem->commision;

                $acumulado = $acumulado + $calculo;


                // agregar movimientos salientes

                $addmov = new movements;
                $addmov->id_item = $items[$i];
                $addmov->id_invoice = $dato_id;
                $addmov->id_user = $request->get('user');
                $addmovin->id_branch = Auth::User()->id_branch;
                $addmovin->id_warehouse = Auth::User()->id_warehouse;
                $addmov->quantity = $cantidad[$i];
                $addmov->created_at = $fechaactual;
                $addmov->save();

            }

            $addhead = new head;
            $addhead->invoice = $dato_id;
            $addhead->client = $request->get('client');
            $addhead->seller = $request->get('user');
            $addhead->created_at = $fechaactual;
            $addhead->save();

            $addcomi = new salescommision;
            $addcomi->seller = $request->get('user');
            $addcomi->invoice = $dato_id;
            $addcomi->total = $acumulado;
            $addcomi->state = 'Nopagado';
            $addcomi->created_at = $fechaactual;
            $addcomi->comments = $request->get('comments');
            $addcomi->save();

            $datoscomision = salescommision::select('id')->orderBy('id', 'desc')->first()->get();
            $idcommision = '';
            foreach ($datoscomision as $value) {
                $idcommision = $value->id;
            }
            // 

            $addcommision = new sales;
            $addcommision->invoice = $dato_id;
            $addcommision->commision = $idcommision;
            $addcommision->created_at = $fechaactual;
            $addcommision->comments = '';
            $addcommision->save();

            $total_q = $request->get('total') / $request->get('number_quota');

            // Si hay que actualizar se consulta y se trae los datos.

            $addacuerdo = new paymentagreement;
            $addacuerdo->client = $request->get('client');
            $addacuerdo->seller = $request->get('user');
            $addacuerdo->invoice = $dato_id;
            $addacuerdo->number_installments = $request->get('number_quota');
            $addacuerdo->period = $request->get('period');
            $addacuerdo->total_quota = $total_q;
            $addacuerdo->total = $request->get('total');
            $addacuerdo->comments = '';
            $addacuerdo->created_at = $fechaactual;
            $addacuerdo->state = 'Activo';
            $addacuerdo->save();

            return $entrada;

        } catch (\Exception $e) {
            return $e;
        }
    }

    public function pagos(request $request)
    {
        try {
            $fechaactual = date("y-m-d H:i:s");

            $consulta = DB::table('payment_agreement')->select('id', 'client')->where('invoice', $request->get('invoice'))->first();

            $addpago = new payments;
            $addpago->payment_agreement = $consulta->id;
            $addpago->collector = $request->get('user');
            $addpago->paymentvalue = $request->get('paymentvalue');
            $addpago->totalrecieve = $request->get('totalrecieve');
            $addpago->iscompletedpayment = $request->get('completedpayment');
            $addpago->finalpayment = $request->get('paymenttotal');
            $addpago->created_at = $fechaactual;
            $addpago->comments = $request->get('comments');
            $addpago->save();

            $total = $request->get('paymenttotal') * 0.10;

            if ($request->get('paymenttotal') == 'No') {
                $consultamorosa = DB::table('delinquent_client')
                    ->where('client', '=', $consulta->client)
                    ->get();

                if (empty($consultamorosa)) {
                    $addmora = new delinquentclient;
                    $addmora->client = $consulta->client;
                    $addmora->payment_agreement = $consulta->id;
                    $addmora->state = 'Activo';
                    $addmora->comments = $request->get('comments');
                    $addmora->created_at = $fechaactual;
                    $addmora->save();
                } else {
                    $actualizar = DB::table('delinquent_client')
                        ->where('client', '=', $consulta->client)
                        ->update(['state' => 'Activo']);
                }

            }

            $addcomi = new salescommision;
            $addcomi->seller = $request->get('user');
            $addcomi->invoice = $consulta->id;
            $addcomi->total = $total;
            $addcomi->state = 'Activo';
            $addcomi->created_at = $fechaactual;
            $addcomi->comments = $request->get('comments');
            $addcomi->save();


        } catch (\Exception $e) {
            return $e;
        }
    }
}
