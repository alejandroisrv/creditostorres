<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class items_seller extends Model
{
    
    public $timestamps=false;

}
