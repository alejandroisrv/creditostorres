<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class acuerdos_pago extends Model
{
    //
}
